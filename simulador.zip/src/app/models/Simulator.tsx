import { count } from "console";
import { Machine } from "./Machine";
import { Machines } from "./Machines";
import { Task } from "./Task";
import { Work } from "./Work";
import { Works } from "./Works";

export class Simulator {
  public machines: Machines;
  public works: Works;
  public clock = 0;

  constructor() {
    this.machines = new Machines();
    this.works = new Works();
  }

  getMachines = () => {
    return this.machines;
  };

  setMachines = (machines: Machines) => {
    this.machines = machines;
  };

  getWorks = () => {
    return this.works;
  };

  setWorks = (works: Works) => {
    this.works = works;
  };

  getClocks = () => {
    return this.clock;
  };

  setClocks = (clock: number) => {
    this.clock = clock;
  };

  updateClock = () => {
    this.clock += 1;
    this.sleep(1000);
    console.log("tiempo de simulacion: " + this.clock);
  };

  sleep = (milliseconds: number) => {
    var start = new Date().getTime();
    for (var i = 0; i < 1e7; i++) {
      if (new Date().getTime() - start > milliseconds) {
        break;
      }
    }
  };

  run = () => {
    this.laodMachines();
    this.loadWorks();
    while (!this.works.simulationEnd()) {
      //actualizar valores
      //imprimir valores
      this.assingWork();
      this.updateClock();
      if(this.clock == 5){
        break
      }
    }
  };

  assingWork = () => {
    let result = this.works.findWorkDontEnd();
    if (result != undefined) {
      if (
        this.machines.getMachineId("A1")?.available &&
        this.machines.getMachineId("A1") == result?.task.machine
      ) {
        this.setInMachine(this.machines.getMachineId('A1'),result.task.task_time,this.works.works[result.workPosition])
      }

      if (
        this.machines.getMachineId("A2")?.available &&
        this.machines.getMachineId("A2") == result?.task.machine
      ) {
        this.setInMachine(this.machines.getMachineId('A2'),result.task.task_time,this.works.works[result.workPosition])

      }

      if (!this.works.works[result?.workPosition + 1].completed) {
        let task =
          this.works.works[result.workPosition + 1].tasks.findTaskDontEnd();
        if (task?.machine.available) {
          this.setInMachine(task.machine,task.task_time,this.works.works[result.workPosition + 1])

        }
      }
    }
    
  };

  setInMachine = (machine:Machine|null,time:number,work:Work) => {
    if(machine != null){
      machine.setAvailable(false);
      machine.setCountDown(time);
      machine.setCurrentWork(work);
    }
    console.log(machine?.toString())
  }

  loadWorks = () => {
    let works = [
      { A1: 1, A2: 2 },
      { A1: 0, A2: 2 },
      { A1: 1, A2: 2 },
      { A1: 1, A2: 2 },
      { A1: 1, A2: 2 },
    ];

    this.works.addWorks(works, this.getMachines());
  };

  laodMachines = () => {
    this.machines.addMachine(["A1", "A2"]);
  };
}
