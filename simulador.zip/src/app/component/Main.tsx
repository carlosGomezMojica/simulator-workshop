import { Simulator } from "./../models/Simulator";

export const Main = () => {
  const run = () => {
    let simulator = new Simulator();
    simulator.run();
  };

  return (
    <body className="container-fluid">
      <header>
        <h1 className="mt-2 mb-2">WorkShop</h1>
        <button type="button" className="btn btn-primary mt-3" onClick={run}>
          Iniciar Simualción
        </button>
      </header>
      <main>
        <div className="row mt-5">
          <div className="col align-self-center">
            <div className="">
              <div className="card" style={{ width: "18rem;" }}>
                <div className="card-header">
                  <h3>Trabajos por Hacer</h3>
                  <i className="fa-solid fa-clipboard-list fa-2x mb-2 mt-2"></i>
                </div>
                <div className="card-body">
                  <ul className="list-group list-group-flush">
                    <li className="list-group-item">An item</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="col align-self-center">
            <div className="container">
              <div className="card" style={{ width: "18rem;" }}>
                <div className="card-header">
                  <h3>Máquina 1</h3>
                  <i className="fa-solid fa-cash-register fa-2x mb-2 mt-2"></i>
                </div>
                <div className="card-body">
                  <ul className="list-group list-group-flush">
                    <li className="list-group-item">An item</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="col align-self-center">
            <div className="container">
              <div className="card" style={{ width: "18rem;" }}>
                <div className="card-header">
                  <h3>Máquina 2</h3>
                  <i className="fa-solid fa-cash-register fa-2x mb-2 mt-2"></i>
                </div>
                <div className="card-body">
                  <ul className="list-group list-group-flush">
                    <li className="list-group-item">An item</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="col align-self-end">
            <div className="card" style={{ width: "18rem;" }}>
              <div className="card-header">
                <h3>Trabajos Terminados</h3>
                <i className="fa-solid fa-clipboard-check fa-2x mb-2 mt-2"></i>
              </div>
              <div className="card-body">
                <ul className="list-group list-group-flush">
                  <li className="list-group-item">An item</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>
    </body>
  );
};
