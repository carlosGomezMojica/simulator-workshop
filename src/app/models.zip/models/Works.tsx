import { Task } from "./Task";
import { Work } from "./Work";

export class Works {
  public works: Work[];

  constructor() {
    this.works = [];
  }

  getWorks = () => {
    return this.works;
  };

  setWorks = (works: Work[]) => {
    this.works = works;
  };

  simulationEnd = () => {
    this.works.forEach((work) => {
      if(!work.completed){
        return false
      }
    });
    return true;
  };

  toString = () => {
    let output = `Works: \n[\n`;
    this.works.forEach((work) => {
      output += " " + work.toString() + "\n";
    });
    return output + `]`;
  };
}
