
export class Simulator{
    public machines = [];
    public works = [];
    public clock = 0;

    constructor(){
    }

    getMachines = () => {
        return this.machines
    }

    setMachines = (machines:[]) => {
        this.machines = machines;
    }

    getWorks = () => {
        return this.works
    }

    setWorks = (works:[]) => {
        this.works = works;
    }

    getClocks = () => {
        return this.clock
    }

    setClocks = (clock:number) => {
        this.clock = clock;
    }
}