import { Machine } from "./Machine";
import { Task } from "./Task";

export class Tasks {
  public tasks: Task[];

  constructor() {
    this.tasks = [];
  }


  getTasks = () => {
    return this.tasks;
  };

  setTasks = (tasks: Task[]) => {
    this.tasks= tasks;
  };

  addTask = (machine:Machine,time:number) =>{
    this.tasks.push(new Task(machine,time));
  }
 
  toString = () => {
    let output = `Tasks: \n[\n`
    this.tasks.forEach((task)=>{
      output += ' ' +task.toString()+ '\n';
    })
    return output +`]`;
  };
}
